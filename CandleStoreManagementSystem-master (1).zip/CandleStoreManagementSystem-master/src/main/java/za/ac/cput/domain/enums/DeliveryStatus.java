package za.ac.cput.domain.enums;

public enum DeliveryStatus {
    AWAITING_DISPATCH,
    IN_TRANSIT,
    DELIVERED,
    FAILED,
    RETURNED
}
