package za.ac.cput.domain.enums;

public enum EmployeeRole {
    MANAGER,
    STAFF,
    DRIVER,
    ADMIN,
    INTERN,
}