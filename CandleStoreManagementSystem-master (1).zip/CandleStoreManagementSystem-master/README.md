[Uploading candle-store-umlFinal2.drawio.pdf…]()
