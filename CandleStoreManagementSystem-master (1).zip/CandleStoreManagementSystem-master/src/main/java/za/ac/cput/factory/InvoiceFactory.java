package za.ac.cput.factory;

public class InvoiceFactory {
}
